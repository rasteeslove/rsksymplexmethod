# Simplex method

A library for simplex method to be uploaded to PyPi for faster use later.

